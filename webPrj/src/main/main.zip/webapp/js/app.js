import GameCanvas from "./ui/game-canvas.js";

window.onload = function(){
    var gameCanvas = new GameCanvas();

    gameCanvas.run();
};
